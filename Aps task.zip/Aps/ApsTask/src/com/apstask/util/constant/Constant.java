package com.apstask.util.constant;

public class Constant {
	// --Driver connection--//

		public final static String DRIVER = "com.mysql.cj.jdbc.Driver";
		public static final String URL = "jdbc:mysql://localhost:3306/task";
		public static final String USERNAME = "root";
		public static final String PASSWORD = "abcd1234";
		// --Driver connection End --//
}
