package com.apstaks.main;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.apstask.util.DbConnection;
public class Insert {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	 Insert (int id, String name,String city,Long num) throws ClassNotFoundException, SQLException
	 {
		 con =DbConnection.GetConnection(); 
		 String sql = "insert into hsp(id,name,city,num)values(?,?,?,?)";
		 pst = con.prepareStatement(sql);
		 pst.setInt(1, id);
		 pst.setString(2,name);
		 pst.setString(3,city);
		 pst.setLong(4,num);
		 pst.execute();
		 System.out.println("Successfull Inserted");
		 con.close();
	 }
}
