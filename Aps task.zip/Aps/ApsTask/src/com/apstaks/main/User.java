package com.apstaks.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.apstask.util.DbConnection;

public class User {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;

	User(String user, String aemail, String apassword) throws ClassNotFoundException, SQLException {
		con = DbConnection.GetConnection();
		String sql = "insert into admin(user,aemail,apassword)values(?,?,?)";
		pst = con.prepareStatement(sql);
		pst.setString(1, user);
		pst.setString(2, aemail);
		pst.setString(3, apassword);
		pst.execute();
		System.out.println("Successfull Created");
		con.close();

	}
}
