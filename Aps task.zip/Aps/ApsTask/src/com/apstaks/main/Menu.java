package com.apstaks.main;

import java.sql.SQLException;
import java.util.Scanner;

public class Menu {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		int n, id;
		String name, city;
		Long num;
		boolean x = false;
		do {
			System.out.println("Enter Above Mention Option: ");
			System.out.println("1. Select hospital Records");
			System.out.println("2. Insert hospital Records");
			System.out.println("3. Delete hospital Records");
			System.out.println("4. Update hospital Records");
			System.out.println("5. select All hospital Records");
			
			Scanner sc = new Scanner(System.in);
			n = sc.nextInt();

			switch (n) {
			case 1:
				System.out.println("1. Hospital Records Selection");
				System.out.println("Please Select id");
				id = sc.nextInt();
				Select select = new Select(id);
				x = true;
				break;
			case 2:
				System.out.println("Hospital Insertion");
				System.out.println("Enter Hospital  id");
				id = sc.nextInt();
				System.out.println("Enter Hospital  Name");
				name = sc.next();
				System.out.println("Enter Hospital  City");
				city = sc.next();
				System.out.println("Enter Hospital  Number");
				num = sc.nextLong();
				Insert insert = new Insert(id, name, city, num);
				x = true;
				break;
			case 3:
				System.out.println("3. Hospital Records Deletion");
				System.out.println("Enter Hospital  id");
				id = sc.nextInt();
				Delete delete = new Delete(id);
				x = true;
				break;
			case 4:
				System.out.println("4. Hospital Records Updation");
				System.out.println("Enter Hospital  Name");
				name = sc.next();
				System.out.println("Enter Hospital  City");
				city = sc.next();
				System.out.println("Enter Hospital  Number");
				num = sc.nextLong();
				System.out.println("Enter Confirm Hospital id You Have To Update");
				id = sc.nextInt();
				Update update = new Update(name, city, num, id);
				x = true;
				break;
			case 5:
				SelectAll selectAll = new SelectAll();
				x = true;
				break;
			default:
				System.out.println(" **-- Invalid Selection--** ");
				x = true;
			}
		} while (x != false);
	}

}
