package com.apstaks.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.apstask.util.DbConnection;

public class Select {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	Select(int id) throws ClassNotFoundException, SQLException {
		con = DbConnection.GetConnection(); 
		String sql = "select * from hsp where id  = ?";
		pst = con.prepareStatement(sql);
		pst.setInt(1, id);
		rs = pst.executeQuery();
		if (rs.next()) {
			int eid = rs.getInt(1);
			String name = rs.getString(2);
			String city = rs.getString(3);
			Long number = rs.getLong(4);
			System.out.println(" | " + eid + " | " + name + " | " + " | " + city + " | " + number);
			System.out.println("----------------------------------------------------");
		}
		else

		{
			System.out.println("Invalid Id");
		}
		rs.close();
		con.close();
	}

}