package com.apstaks.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.apstask.util.DbConnection;

public class Login {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	int l;

	Login(String email, String password) throws ClassNotFoundException, SQLException {
		con = DbConnection.GetConnection();
		String sql = "select * from paitence where email=? and password=? ";
		pst = con.prepareStatement(sql);
		pst.setString(1, email);
		pst.setString(2, password);
		rs = pst.executeQuery();
		if (rs.next()) {
			String name = rs.getString(2);
			Long phone = rs.getLong(3);
			email = rs.getString(4);
			String address = rs.getString(5);
			String state = rs.getString(6);
			String city = rs.getString(7);
			int pincode = rs.getInt(8);
			String date = rs.getString(9);
			password = rs.getString(10);
			System.out.println(
					"--------------------------------------------------------------------------------------------------------");
			System.out.println(" | " + name + " | " + phone + " | " + " | " + email + " | " + "|" + address + "|"
					+ state + "|" + city + "|" + pincode + "|" + date + "|" + password);
			System.out.println(
					"--------------------------------------------------------------------------------------------------------");
			System.out.println("Enter Above Mention Option: ");
			System.out.println("1. Forget password");
			System.out.println("2. Change password");
			System.out.println("3. Update details");
			System.out.println("4. Logout");

			Scanner sc = new Scanner(System.in);
			l = sc.nextInt();
			switch (l) {
			case 1:
				System.out.println("Enter email");
				email = sc.next();
				System.out.println("Enter Password");
				password = sc.next();
				Forget forget = new Forget(email, password);

				break;
			case 2:
				System.out.println("Enter email");
				email = sc.next();
				System.out.println("Enter old Password");
				String opassword = sc.next();
				System.out.println("Enter New Password");
				password = sc.next();
				Change change = new Change(email, opassword, password);

				break;
			case 3:
				System.out.println("Enter Name");
				name = sc.next();
				System.out.println("Enter Phone");
				phone = sc.nextLong();
				System.out.println("Enter Address");
				address = sc.next();
				System.out.println("Enter State");
				state = sc.next();
				System.out.println("Enter City");
				city = sc.next();
				System.out.println("Enter Pincode");
				pincode = sc.nextInt();
				System.out.println("Enter Email");
				email = sc.next();
				UpdatePaitence upd = new UpdatePaitence(name, phone, address, state, city, pincode, email);

				break;
			case 4:
				break;

			default:
				break;
			}
		} else

		{
			System.out.println("Invalid User");
		}
		rs.close();
		con.close();
	}

}
