package com.apstaks.main;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.apstask.util.DbConnection;
public class UpdatePaitence {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	UpdatePaitence(String name, Long phone,String address,String state,String city,int pincode,String email) throws ClassNotFoundException, SQLException {
		con = DbConnection.GetConnection();
		String sql = "update paitence set name=?,phone=?,address=?, state=?,city=?,pincode=?,where email=?";
		pst = con.prepareStatement(sql);
		pst.setString(1, name);
		pst.setLong(2, phone);
		pst.setString(3, address);
		pst.setString(4, state);
		pst.setString(5, city);
		pst.setInt(6, pincode);
		pst.setString(7, email);
		pst.executeUpdate();
		System.out.println("Updation Done");
		con.close();
	}

}
