package com.apstaks.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.apstask.util.DbConnection;

public class Change {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;

	Change(String email,String opassword, String password) throws ClassNotFoundException, SQLException {
		String sql = "update paitence set password=? where email = ?";
		con = DbConnection.GetConnection();
		pst = con.prepareStatement(sql);
		pst.setString(1, password);
		pst.setString(2, email);
		pst.executeUpdate();
		System.out.println("password change successfully");
		con.close();
	}
		
	}


